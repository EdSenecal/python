-- use dojo_and_ninjas;
-- INSERT INTO dojos (name) 
-- VALUES ("HIDDEN CRANE");
-- INSERT INTO dojos (name)
-- VALUE ("CROUCHING DRAGON");

-- INSERT INTO dojos (name)
-- VALUE ("CHUNKY CHINCHILLA");

-- we are updating with id to delete contents on purpose and save a step.  
-- UPDATE dojos set name= "POISON HAND" WHERE ID=1;
-- UPDATE dojos set name= "POISON TOE" WHERE ID=2;
-- UPDATE dojos set name= "POISON ELBOW" WHERE ID=3;

-- insert into ninjas (first_name,last_name,age, dojo_id)
-- value ("jane", "doe", 42, 3);
-- insert into ninjas (first_name,last_name,age, dojo_id)
-- value ("jason", "brady", 19, 1);
-- insert into ninjas (first_name,last_name,age, dojo_id)
-- value ("john", "smith", 42, 2);
-- insert into ninjas (first_name,last_name,age, dojo_id)
-- -- value ("ninja", "two", 22, 1);
-- value ("ninja", "three", 33, 1);

-- insert into ninjas (first_name,last_name,age, dojo_id)
-- value ("ninja", "two", 22, 2);

-- insert into ninjas (first_name,last_name,age, dojo_id)
-- value ("ninja", "three", 33, 2);

-- insert into ninjas (first_name,last_name,age, dojo_id)
-- value ("ninja", "two", 22, 3);

-- insert into ninjas (first_name,last_name,age, dojo_id)
-- value ("ninja", "three", 33, 3);

-- SELECT * FROM dojos;
-- SELECT * FROM ninjas where dojo_id = 1;
-- SELECT * FROM ninjas where dojo_id = 2;
-- SELECT * FROM ninjas where dojo_id = 3;
-- select * from ninjas where id = 9;     
-- i didn't put them in a nice order so this returns a weird result, but its correct

-- select * from ninjas;